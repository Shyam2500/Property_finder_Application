import React, { Component } from 'react'

export default class NotFound extends Component {
    render() {
        return (
            <div>
                <h1 className="display-1">Page Not Found</h1>
            </div>
        )
    }
}
