package com.app.exception;

public class UserException extends RuntimeException {
public UserException(String msg) {
	// TODO Auto-generated constructor stub
	super(msg);
}
	
}
