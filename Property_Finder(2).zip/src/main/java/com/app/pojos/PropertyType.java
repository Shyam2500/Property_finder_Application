package com.app.pojos;

public enum PropertyType {
ONEBHK,TWOBHK,THREEBHK,FOURBHK,BANGLOW,VILLA,PLOT;
}
