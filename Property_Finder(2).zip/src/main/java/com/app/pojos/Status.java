package com.app.pojos;

public enum Status {
AV,NAV;
}
