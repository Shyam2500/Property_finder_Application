package com.app.pojos;


public enum OwnerChoice {
RENT,SELL;
}
